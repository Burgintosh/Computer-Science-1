#include <iostream>

class String {
    
}

int main() {

}